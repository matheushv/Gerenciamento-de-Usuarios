package projeto.servico;

public class Pessoa {
    String nome;
    String cpf;
    String datanasc;
    
    
    void imprimiPessoa() {
        System.out.println("Nome : " + this.nome);
        System.out.println("CPF: " + this.cpf);
        System.out.println("Data de nascimento: " + this.datanasc); 
    }

    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }

    public String getDatanasc() {
        return datanasc;
    }
}
